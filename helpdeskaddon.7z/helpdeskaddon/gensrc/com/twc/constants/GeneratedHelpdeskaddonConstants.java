/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Sep 17, 2017 10:37:20 AM                    ---
 * ----------------------------------------------------------------
 */
package com.twc.constants;

/**
 * @deprecated use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedHelpdeskaddonConstants
{
	public static final String EXTENSIONNAME = "helpdeskaddon";
	public static class TC
	{
		public static final String CREATETICKETCMSCOMPONENT = "CreateTicketCMSComponent".intern();
		public static final String HELPDESKCREATETICKETCMSCOMPONENT = "HelpDeskCreateTicketCMSComponent".intern();
	}
	public static class Attributes
	{
		// no constants defined.
	}
	
	protected GeneratedHelpdeskaddonConstants()
	{
		// private constructor
	}
	
	
}
