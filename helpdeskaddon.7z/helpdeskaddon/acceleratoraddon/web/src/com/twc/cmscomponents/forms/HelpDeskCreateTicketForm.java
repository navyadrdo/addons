package com.twc.cmscomponents.forms;

/**
 * Created by janos.resz@jpard.com on 1/22/2016.
 */
public class HelpDeskCreateTicketForm
{
	private String name;
	private String email;
	private String zip;
	private String shop;
	private String error;

	/**
	 * @return the error
	 */
	public String getError()
	{
		return error;
	}

	/**
	 * @param error
	 *           the error to set
	 */
	public void setError(final String error)
	{
		this.error = error;
	}

	private String success;

	/**
	 * @return the success
	 */
	public String getSuccess()
	{
		return success;
	}

	/**
	 * @param success
	 *           the success to set
	 */
	public void setSuccess(final String success)
	{
		this.success = success;
	}

	/**
	 * @return the shop
	 */
	public String getShop()
	{
		return shop;
	}

	/**
	 * @param shop
	 *           the shop to set
	 */
	public void setShop(final String shop)
	{
		this.shop = shop;
	}

	public String getName()
	{
		return name;
	}

	public void setName(final String name)
	{
		this.name = name;
	}

	public String getEmail()
	{
		return email;
	}

	public void setEmail(final String email)
	{
		this.email = email;
	}

	public String getZip()
	{
		return zip;
	}

	public void setZip(final String zip)
	{
		this.zip = zip;
	}
}
