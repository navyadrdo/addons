/*package com.twc.cmscomponents.renderer;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.jsp.PageContext;

import org.apache.commons.lang.StringUtils;

import de.hybris.platform.commercefacades.user.data.CustomerData;
import hu.euronics.cmscomponents.forms.HelpDeskCreateTicketForm;
import hu.euronics.cmscomponents.model.HelpDeskCreateTicketCMSComponentModel;
import hu.euronics.facades.commercefacades.customer.EuronicsCustomerFacade;

 *//**
 * Created by janos.resz@jpard.com on 1/22/2016.
 */
/*
 * public class HelpDeskCreateTicketCMSComponentRenderer<C extends helpdesk> extends DefaultAddOnCMSComponentRenderer<C>
 * {
 * 
 * 
 * @Override protected Map<String, Object> getVariablesToExpose(final PageContext pageContext, final
 * HelpDeskCreateTicketCMSComponentModel component) { final Map<String, Object> variablesToExpose =
 * super.getVariablesToExpose(pageContext, component);
 * 
 * final com.twc.cmscomponents.forms.HelpDeskCreateTicketForm helpDeskCreateTicketForm = new
 * com.twc.cmscomponents.forms.HelpDeskCreateTicketForm();
 * 
 * 
 * if (null == getRequest().getAttribute("helpDeskCreateTicketForm")) {
 * variablesToExpose.put("helpDeskCreateTicketForm", helpDeskCreateTicketForm); }
 * 
 * return variablesToExpose; } }
 */